# Bulk Delete Organizations

This app offers an easy way to delete many organisations at one time.

Please submit bug reports to [this email address](mailto:ncolfer@zendesk.com). Pull requests are welcome.